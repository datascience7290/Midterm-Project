#install.packages("tree")
library (tree)
library (MASS)
library (ISLR)
library(rpart)
setwd('/Users/shivamgoel/desktop/Midterm/RegressionTree')
PerformanceMetrics_new <- NULL
combined_array <- list()


i = 0;

for(i in 17:length(list_dataframes_x))
{
#i<-78
Treedataset <- NULL  
Treedataset <- list_dataframes_x[[i]]
#View(Treedataset)

if(nrow(Treedataset) != nrow(Treedataset[Treedataset$kwh_per_meter_sq == 0, ]))
{
datasets_name = NULL
dataset_meternumb = NULL
name = NULL

dataset_name = unique(list_dataframes[[i]]$BuildingID)
dataset_meternumb = unique(list_dataframes[[i]]$meternumb)
name <-paste0(dataset_name,"_",dataset_meternumb)
#Treedataset <- read.csv("sampleFormat.csv")
#View(Treedataset)

set.seed(123)
#Treedataset <- subset(Treedataset, select=c(7,10,11,12,13,14,21,24:31))
#colnames(Treedataset)[4] <- "dayofweek"
#selecting my new subset

#Training data
train = sample (1:nrow(Treedataset), nrow(Treedataset)/2)
testdata <- Treedataset[-train,]
names(testdata)
testdata <- subset(testdata, select=c(7,10,11,12,13,14,24:29))

names(Treedataset)
tree.dataset = tree(kwh_per_meter_sq ~ TemperatureF+Dew_PointF+Humidity+Sea_Level_PressureIn+Wind_SpeedMPH+Gust_SpeedMPH+WindDirDegrees+Gust_SpeedMPH+hour+Month+Day+Weekday,Treedataset,subset=train)
summary(tree.dataset)


#Plotting Tree
plot (tree.dataset)
text(tree.dataset,pretty=0)
tree.dataset = NULL
cv.weather = NULL
#class(cv.weather)
tree.dataset = tree(kwh_per_meter_sq ~ TemperatureF+Dew_PointF+Sea_Level_PressureIn+Wind_SpeedMPH+Gust_SpeedMPH,Treedataset,subset=train)

#cv.weather <- cv.tree(tree.dataset, FUN = prune.tree)
#plot (cv.weather$size, cv.weather$dev, type='b')

#Using Unpruned tree to make prediction
yhat <- NULL
yhat=predict(tree.dataset, newdata = Treedataset [-train,])
testdata <- Treedataset [-train,"kwh_per_meter_sq"]

weather.test=Treedataset [-train,"kwh_per_meter_sq"]
plot(yhat,weather.test)
abline (0,1)
mean((yhat -weather.test)^2)

#Pruning of the tree
prune.weather = prune.tree(tree.dataset, best = 3)
plot(prune.weather)
text(prune.weather, pretty = 0)

#cv.prune = cv.tree (prune.weather)
plot (cv.prune$size, cv.prune$dev, type='b')

yhat=predict (prune.weather, newdata =Treedataset [-train,])
weather.test=Treedataset [-train,"kwh_per_meter_sq"]
plot(yhat,weather.test)
abline (0,1)
mean((yhat -weather.test)^2)

#Predicting the accuracy of model
acc <- NULL
acc<-accuracy(yhat,weather.test)
PerformanceMetrics <- NULL
PerformanceMetrics<-as.data.frame(acc)
#View(PerformanceMetrics_new)

PerformanceMetrics$name <- name
colnames(PerformanceMetrics) <- c("ME","RMSE","MAE","MPE","MAPE","name")
PerformanceMetrics_new <- rbind(PerformanceMetrics_new,PerformanceMetrics)


#Creating Prediction column
forecastOutput <- cbind(weather.test,yhat,testdata)
#View(forecastOutput)
forecastOutput<-as.data.frame(forecastOutput)
#residuals
forecastOutput$residuals<-weather.test-yhat
forecastOutput$outlier_flag<-NULL
#compute sd
for(i in seq(from=1, to=length(forecastOutput$residuals))){
  forecastOutput$outlier_flag[i] <- ifelse(forecastOutput$residuals[i]>=2*sd(forecastOutput$residuals),"T","F")
}
write.csv(forecastOutput,paste0("Building_",name,".csv"))
print(i)
}
}




write.csv(PerformanceMetrics_new,"PerformanceOutput_78.csv")


for(i in 1:length(list_dataframes))
{
  write.csv(list_dataframes[[i]],paste0("Middataframes_",i,".csv"))
}
