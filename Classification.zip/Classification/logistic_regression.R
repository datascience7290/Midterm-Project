#Some descriptive statistics of Consumption data
setwd('/Users/hinagandhi/desktop/logistic_regression_classification')
install.packages('e1071', dependencies=TRUE)
building_id <- NULL
confusion_matrix_random <- NULL
for(i in 1:length(obj_name_power))
{
data_logi <- list_dataframes_x[[i]]
#data_logi <- data_logi[,c(18,6,8,9,10,12,16,14,19,20,21,22,24,26,28)]
summary(data_logi)
name <- paste0("buildingID_",data_logi$BuildingID[i],"_meternumb_",data_logi$meternumb[i])
data_logi$base_hr_class <- as.factor(data_logi$base_hr_class)
data_logi$base_hr_class<-ifelse(data_logi$base_hr_class=="HIGH", 1,0)
data_logi$base_hr_class<-factor(data_logi$base_hr_class,levels=c(0,1),labels=c("LOW","HIGH"))
table(data_logi$base_hr_class)
colnames(data_logi)[12] <- "dayofweek"
#Construct a logistic regression model for factor Base_Hour_Class using all other variables 
drops <- c("BuildingID","vac", "meternumb","type","date","Holiday",
           "Base_hour_Flag","Address","FloorArea_mSqr","Latitude","Longitude","nearestAirport",
           "Conditions","Wind_Direction","Events","Year","X.x","X.y","kwh_per_meter_sq")
data_logi <- data_logi[ , !(names(data_logi) %in% drops)]
fit1<-glm(base_hr_class~Month+hour+Day+TemperatureF+Dew_PointF+Humidity+Sea_Level_PressureIn+VisibilityMPH+WindDirDegrees+Wind_SpeedMPH+Consumption
          +dayofweek+Weekday,data=data_logi,family=binomial(link="logit"))
summary(fit1)

#Construct a logistic regression model for factor Base_Hour_Class 
fit2 <- glm(base_hr_class ~ Month + hour + Day + TemperatureF + Humidity + Sea_Level_PressureIn + Consumption + Weekday,
            data=data_logi, family=binomial(link="logit"))
summary(fit2)

#Parameters of fit2
coef(fit2)

#Predict the probability of the outcome
newdata <- data.frame(Month=mean(data_logi$Month),
                      Sea_Level_PressureIn=mean(data_logi$Sea_Level_PressureIn),
                      Consumption=mean(data_logi$Consumption),
                      Weekday=mean(data_logi$Weekday),
                      Day = mean(data_logi$Day),
                      TemperatureF = mean(data_logi$TemperatureF),
                      Humidity = mean(data_logi$Humidity),
                      hour = mean(data_logi$hour))
newdata
prob <- predict(fit2, newdata=newdata, type="response")
prob


#Split the data into training and testing
smp_size <- floor(0.80 * nrow(data_logi))
set.seed(123)
train_ind <- sample(seq_len(nrow(data_logi)), size = smp_size)
train <- data_logi[train_ind,]
test <- data_logi[-train_ind,]
#Build a logistic regression model on the training data
fit <- glm(base_hr_class ~ Month + hour + Day + TemperatureF + Humidity + Sea_Level_PressureIn + Consumption + Weekday,
           data=data_logi, family=binomial(link="logit"))
summary(fit)

#Run the model on the test set with cutoff value = 0.5
test.probs <- predict(fit,test,type="response")
pred <- rep("HIGH",length(test.probs))
pred[test.probs>=0.5] <- "LOW"

#classification matrix using confusionMatrix() function in caret package
library(caret)
table <- table(as.factor(test$base_hr_class), as.factor(pred))
table
#confusionMatrix(as.factor(test$base_hr_class), as.factor(pred),positive = TRUE)
#Generate ROC curve using ROCR package
library(ROCR)
pred <- as.factor(pred)
prediction <- prediction(test.probs , test$base_hr_class)
performance <- performance(prediction, measure = "tpr",x.measure = "fpr")
plot(performance, main = "ROC curve", xlab = "1-Specificity", ylab = "Sensitivity")

auc <- performance(prediction, measure = "auc")
auc <- auc@y.values[[1]]
auc
text(0.5,0.5,paste("AUC = ",format(auc, digits=5, scientific=FALSE)))
#Generate cumulative lift curve using lift() function in caret package
test$probs = test.probs
test$probs = sort(test$probs, decreasing = T)
lift <- lift(base_hr_class ~ prob, data = test)
lift
xyplot(lift, plot = "gain")

test_data <- test
test_data <- as.data.frame(test_data)
prediction_data <- as.data.frame(pred)
test_data <- cbind(test_data, prediction_data)
day <-test_data$Day[1] 
count <- 0
test_data <- test_data[order(test_data$Month,test_data$Day,test_data$hour),]
for(i in 1:nrow(test_data))
{
  if(test_data$Day == day )
  {
    if(test_data$pred[i]!=test_data$Consumption[i])
    {count <- count+1}
    if(count >= 6)
    {test_data$Outlier_day[i] <- "TRUE"}else
    {test_data$Outlier_day[i] <- "FALSE"}
  }else{count <- 0}
  day <- test_data$Day
}
building_id$name <- name
write.csv(test_data,paste0(name,"_prediction_",".csv"))
building_desc <- cbind(table, building_id)
confusion_matrix_random <- rbind(confusion_matrix_random,building_desc)
}
write.csv(confusion_matrix_random,"Logistic_Regression_ConfusionMatrix.csv")
