#install.packages("rjson")
library("rjson")
library("tidyr") # to restructure data
library("ggplot2") # to draw figures efficiently
# reading config file
setwd('/Users/shivamgoel/desktop/Midterm')
json_data <- fromJSON(file="config.json")
json_data
i = 0;
j=0;

for(i in 1:length(list_dataframes_x))
{

inputRead <- list_dataframes_x[[i]]
names(inputRead)
drops <- c("X","BuildingID","vac", "meternumb","type","date","Holiday",
          "Base_hour_Flag","Address","FloorArea_mSqr","Latitude","Longitude","nearestAirport",
          "Conditions","Wind_Direction","Events","Year","X.x","X.y","kwh_per_meter_sq","base_hr_class")
inputRead <- inputRead[ , !(names(inputRead) %in% drops)]

#k-means

###changing with this####
sample_data <- sample(1:nrow(inputRead),round(0.60*nrow(inputRead)))                        
kmeansdata <- inputRead[sample_data,]
nrow(kmeansdata)
####################

names(inputRead)
#View((kmeansdata))
#View(summary(inputRead))
#km.out <- kmeans(inputRead,3,nstart = 10)
if(json_data$distance_measure == 'Euclidean'){
  km.out <- kmeans(inputRead,as.numeric(json_data$Number_of_clusters),nstart = as.numeric(json_data$nstart))
  
} else if (json_data$distance_measure == 'manhattan' || json_data$distance_measure == 'correlation'){
  
  km.out <- kmeans(inputRead,as.numeric(json_data$Number_of_clusters),iter.max = 1000,nstart=as.numeric(json_data$nstart), method=json_data$distance_measure)  
  
} 

km.out$cluster

#cluster tagging
View(cbind(inputRead,km.out$cluster))
View(inputRead)

plot(inputRead, col=(km.out$cluster), main = "K-mean results")
error.freq.long <- gather(inputRead, tag, freq)
# first few lines
head(error.freq.long)


#### Hierarchical clustering
sample_data <- sample(1:nrow(inputRead),round(0.60*nrow(inputRead)))                        

kmeansdata <- inputRead[sample_data,]
kmeanstestdata <- inputRead[-sample_data]

inputRead=scale(kmeansdata) #Scaling the data
hc.complete=hclust(dist(inputRead),method="complete") # Complete linkage type
hc.average=hclust(dist(inputRead),method="average")  # Average linkage type

par(mfrow=c(1,2)) #Plotting in a matrix form
#plot(hc.complete,main='Complete')
#plot(hc.average,main='Average')

View(cbind(inputRead,cutree(hc.complete,11)))
#plot(cutree(hc.average,3))


### Bend Graph
sample_data <- sample(1:nrow(inputRead),round(0.75*nrow(inputRead)))                        
kmeansdata <- inputRead[sample_data,]
nrow(kmeansdata)
names(inputRead)
inputRead=scale(kmeansdata) #Scaling the data
wss <- (nrow(inputRead)-1)*sum(apply(inputRead,2,var))
for(i in 2:15){
  wss[i] <- sum(kmeans(inputRead,centers = i)$withinss)
}

plot(1:15, wss,type="b",xlab = "Number of clusters", ylab="Within groups sum of squares")

}