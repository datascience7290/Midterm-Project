install.packages("neuralnet")
install.packages("forecast")
library (MASS)
library (grid)
library (neuralnet)
library(forecast)
setwd('/Users/shivamgoel/desktop/midterm')
performance_metrics_neural <- NULL
mean_x <- NULL
normalize <- function(x) {
  return ((x - min(x)) / (max(x) - min(x))) }

rmse <- function(error) {
  sqrt(mean(error^2))
}

# Function that returns Mean Absolute Error
mae <- function(error)  {
  mean(abs(error))
}

# Function that returns Mean Absolute Percentage Error
mape <- function(error)  {
  x <- as.data.frame(abs(error/Neuraldataset$kwh_per_meter_sq))
  colnames(x)[1] <- "measures"
  mean_x = mean(x$measures)
  mean_x
}

for( i in 1:length(list_dataframes_x))
{i<-1
  Neuraldataset <- NULL
  Neuraldataset <- list_dataframes_x[[i]]
  name <- paste0("buildingID_",Neuraldataset$BuildingID[i],"_meternumb_",Neuraldataset$meternumb[i])
  #View(list_dataframes_x[[1]])
  colnames(Neuraldataset)[12] <- "dayofweek"
  #Dropping Unncessary column
  drops <- c("BuildingID","vac", "meternumb","type","date","Holiday",
             "Base_hour_Flag","Address","FloorArea_mSqr","Latitude","Longitude","nearestAirport","base_hr_class",
             "Conditions","Wind_Direction","Events","Year")
  Neuraldataset <- Neuraldataset[ , !(names(Neuraldataset) %in% drops)]
  #selecting my new subset
  dataneural <- as.data.frame(lapply(Neuraldataset, normalize))
  #View(dataneural)
  
  train <- sample(1:nrow(dataneural),round(0.75*nrow(dataneural)))
  traindata <- dataneural[train,]
  testdata <- dataneural[-train,]
  #View(testdata)
  
  
  #training neural net for th model
  netsqrt <- neuralnet(kwh_per_meter_sq ~ dayofweek + hour + TemperatureF + Dew_PointF + Humidity + Sea_Level_PressureIn + VisibilityMPH +Day + Wind_SpeedMPH + WindDirDegrees + Month, data=traindata, hidden=c(4,3,3), threshold=0.5, linear.output = F)
  
  
  #print the error result
  print(netsqrt)
  
  #Plot the neural network
  #plot(netsqrt)
  
  #Test the neural network on some training data
  actual <- testdata$kwh_per_meter_sq
  #View(actual)
  drops <- c("kwh_per_meter_sq")
  testdata <- testdata[ , !(names(testdata) %in% drops)]
  #View(testdata)
  #debugonce(neuralnet)
  results <- compute(netsqrt, testdata[,c(2,4,5,6,10:16)]) #Run them through the neural network
  #View(results)
  #accuracy of the algorithm
  #netsqrt <- accuracy(actual,netsqrt)
  #View(netsqrt)
  ls(results)
  #Lets see the results
  print(results$net.result)
  #denormalized the data
  denormalize <- function(x) {
    return ((x * (max(x) - min(x))) + min(x))
  }
  
  
  resultset <- as.data.frame(sapply(results$net.result, denormalize))
  #View(resultset)
  
  
  #computing performance of the algorithm
  error = (resultset - Neuraldataset$kwh_per_meter_sq)
  
  # Function that returns Root Mean Squared Error
  
  #calculating mean square value
  rmse(error)
  rms <- c("RMS", rmse(error))
  ma <- c("MAE", mae(error[[1]]))
  map <- c("MAPE", mape(error[[1]]))
  neural_performance <- NULL
  neural_performance$rms <- rms[2]
  neural_performance$ma <- ma[2]
  neural_performance$map <- map[2]
  neural_performance$name <- name
  if(is.null(neural_performance)){}else
  {performance_metrics_neural <- rbind(performance_metrics_neural,neural_performance)}
}

write.csv(performance_metrics_neural,"Performance_Neural_78.csv")