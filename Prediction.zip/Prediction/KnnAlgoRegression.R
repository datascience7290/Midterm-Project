install.packages("FNN")
library(FNN)
setwd('/Users/shivamgoel/desktop/Midterm')
RegTreedataset <- list_dataframes_x[[1]]
View((RegTreedataset))


#Dropping Unncessary column
drops <- c("X","BuildingID","vac", "meternumb","type","date","Holiday",
           "Base_hour_Flag","Address","FloorArea_mSqr","Latitude","Longitude","nearestAirport","base_hr_class",
           "Conditions","Wind_Direction","Events","Year")
RegTreedataset <- RegTreedataset[ , !(names(RegTreedataset) %in% drops)]

normalize <- function(x) {
  return ((x - min(x)) / (max(x) - min(x))) }

#selecting my new subset
dataregtree <- as.data.frame(lapply(RegTreedataset, normalize))
#View(dataneural)

train <- sample(1:nrow(dataregtree),round(0.75*nrow(dataregtree)))
traindata <- dataregtree[train,]
testdata <- dataregtree[-train,]
View(testdata)


tree_reg<-knn.reg(traindata,y=traindata$kwh_per_meter_sq,testdata,k=3)
testdata$kwh_per_meter_sq


head(testdata$kwh_per_meter_sq)
error=as.double(tree_reg[[4]])-testdata$kwh_per_meter_sq

accuracy(tree_reg[[4]],testdata$kwh_per_meter_sq)


