bostonnnet <- list_dataframes_x[[1]]
View((bostonnnet))


#1. we need to check for missing values and look how many unique values there are for each variable using the sapply() function which applies the function passed as argument to each column of the dataframe.
sapply(trainBosnnet,function(x) sum(is.na(x)))
sapply(trainBosnnet, function(x) length(unique(x)))

#Amelia package has a special plotting function missmap() that will plot your dataset and highlight missing values
#install.packages("Amelia")
library(Amelia)
missmap(trainBosnnet, main = "Missing values vs observed")

datannet <- bostonnnet


nrow(datannet)

datannet$base_hour_factor <- factor(datannet$base_hr_class, levels = c("HIGH", "LOW"), labels = c("1", "0"))
#View(datannet)
#Dropping Unncessary column
drops <- c("X","BuildingID","vac", "meternumb","type","date","Holiday",
           "Base_hour_Flag","Address","FloorArea_mSqr","Latitude","Longitude","nearestAirport","base_hr_class",
           "Conditions","Wind_Direction","Events","Year")
dfnnet <- datannet[ , !(names(datannet) %in% drops)]
#normalizing the data
normalize2 <- function(x) {
  return ((x - min(x)) / (max(x) - min(x))) }


dfnnet$base_hour_factor<- as.numeric(dfnnet$base_hour_factor)
#View(dfnnet)

#normalizing the datannet
datannet_n <- as.data.frame(lapply(dfnnet, normalize2))
#View(datannet_n)

#import the function from Github
#install.packages("clusterGeneration")
#install.packages("neuralnet")
library(devtools)
library(nnet)
require(nnet)
library(neuralnet)

#Sampling
#75% of the sample size
class_new <- floor(0.75 * nrow(datannet_n))

#Set the seed to make your partition reproductible
set.seed(13)
train_bostonnnet <- sample(seq_len(nrow(datannet_n)), size = class_new)
#View(train_bostonnnet)

#Split the data into training and testing
trainBosnnet <- datannet_n[train_bostonnnet, ]
testBosnnet<- datannet_n[-train_bostonnnet, ]
#View(trainBosnnet)
names(trainBosnnet)
#applying the neural net algorithm
#fitnn <- neuralnet(KWH_factor ~ month + day + Weekday + hour + Peakhour + Temp, data = trainBosnnet, hidden=c(6), threshold=0.5, linear.output = F)
neuralnet <- neuralnet(case ~ age + parity + induced + spontaneous, data=infert, 
                       hidden=3, err.fct="sse", linear.output=FALSE)
fitnn <- nnet(base_hour_factor ~ Day.of.Week + Consumption+hour + TemperatureF + Dew_PointF + Humidity + Sea_Level_PressureIn + VisibilityMPH +Day + Wind_SpeedMPH + WindDirDegrees + Month, data=trainBosnnet,hidden=3, err.fct="sse", linear.output=FALSE,size=1)
fitnn$fitted.values
summary(fitnn)
View(as.data.frame(fitnn))
plot.nnet(fitnn)
