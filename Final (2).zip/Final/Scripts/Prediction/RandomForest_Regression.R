# Random Forest prediction of Kyphosis data
library(randomForest)
PerformanceMetrics_new <- NULL

set.seed(123)
for( i in 1:length(list_dataframes_x))
{
data_reg_random_forest <- list_dataframes_x[[i]]
dataset_name = unique(list_dataframes[[i]]$BuildingID)
dataset_meternumb = unique(list_dataframes[[i]]$meternumb)
name <-paste0(dataset_name,"_",dataset_meternumb)
index_1 <- sample(1:nrow(data_reg_random_forest),round(0.75*nrow(data_reg_random_forest)))
index_original_1 <- index_1
train <- data_reg_random_forest[index_1,]
test <- data_reg_random_forest[-index_1,]

fit <- randomForest(kwh_per_meter_sq ~   hour + TemperatureF + Dew_PointF + Humidity + Sea_Level_PressureIn + VisibilityMPH +Day + Wind_SpeedMPH + WindDirDegrees + Month,   data = train)
print(fit) # view results 
importance(fit) # importance of each predictor
predicion_random_forest <- predict(fit, test)

acc <- NULL
acc<-accuracy(predicion_random_forest, test$kwh_per_meter_sq)
PerformanceMetrics <- NULL
PerformanceMetrics<-as.data.frame(acc)
#View(PerformanceMetrics_new)

PerformanceMetrics$name <- name
colnames(PerformanceMetrics) <- c("ME","RMSE","MAE","MPE","MAPE","name")
PerformanceMetrics_new <- rbind(PerformanceMetrics_new,PerformanceMetrics)
}
write.csv(PerformanceMetrics_new,"PerformanceOutput_Regression_78.csv")
