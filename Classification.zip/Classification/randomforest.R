install.packages("caret")
setwd('/Users/hinagandhi/desktop/random_forest_classification')
install.packages("randomForest")
set.seed(123)
building_id <- NULL
confusion_matrix_random <- NULL
#length(obj_name_power)
for(i in 1:length(obj_name_power))
{
data <- as.data.frame(list_dataframes_x[[i]])
colnames(data)[12] <- "dayofweek"
library(ggplot2)
base_hr_class ~ TemperatureF + hour + dayofweek + Weekday + 
  month + Holiday + Consumption + area_floor._m.sqr + Dew_PointF + 
  Humidity + Sea_Level_PressureIn + VisibilityMPH + Wind_SpeedMPH + 
  WindDirDegrees
name <- paste0("buildingID_",data$BuildingID[i],"_meternumb_",data$meternumb[i])
data$base_hr_class <- as.factor(data$base_hr_class)
data <- data[,c(7,12,10,14,11,15,8,17,25:31,23)]
library(randomForest)
table(data$base_hr_class)/nrow(data)
#High          Low 
#0.5353793691 0.4646206309

#53% of the observations has target variable âHighâ and remaining 46% observations take value âLowâ.

#Now, we will split the data sample into development and validation samples.

sample <- sample(2, 
                     nrow(data),
                     replace = T,
                     prob = c(0.6,0.4))
train <- data[sample==1,]
test <- data[sample==2,]

table(train$base_hr_class)/nrow(train)
#        High          Low 
#0.5331720105 0.4668279895  

table(test$base_hr_class)/nrow(test)
#High          Low 
#0.5387453875 0.4612546125 

class(train$base_hr_class)

## [1] "factor"

varNames <- names(train)
# Exclude ID or Response variable
varNames <- varNames[!varNames %in% c("base_hr_class")]

# add + sign between exploratory variables
varNames1 <- paste(varNames, collapse = "+")

# Add response variable and convert to a formula object
rf.form <- as.formula(paste("base_hr_class", varNames1, sep = " ~ "))

#cross.sell.rf <- randomForest(rf.form,
 #                             cross.sell.dev,
 #                             ntree=500,
  #                            importance=T)

cross.sell.rf <- randomForest(rf.form,
                             train,
                             ntree=500,
                             importance=T)

cross.sell.rf.test <- randomForest(rf.form,
                              test,
                              ntree=500,
                              importance=T)
                              
plot(cross.sell.rf)

# Variable Importance Plot
varImpPlot(cross.sell.rf,
           sort = T,
           main="Variable Importance",
           n.var=5)

# Variable Importance Table
var.imp <- data.frame(importance(cross.sell.rf,
                                 type=2))
# make row names as columns
var.imp$Variables <- row.names(var.imp)
var.imp[order(var.imp$MeanDecreaseGini,decreasing = T),]

# Predicting response variable
train$predicted.response <- predict(cross.sell.rf ,train)

#Confusion Matrix

#confusionMatrix function from caret package can be used for creating confusion matrix based on actual response variable and predicted value.

# Load Library or packages
library(e1071)
library(caret)
## Loading required package: lattice
## Loading required package: ggplot2
# Create Confusion Matrix
confusionMatrix(data=train$predicted.response,
                reference=train$base_hr_class,
                positive='LOW')

# Predicting response variable
test$predicted.response <- predict(cross.sell.rf ,test)

# Create Confusion Matrix
output <- confusionMatrix(data=test$predicted.response,
                reference=test$base_hr_class,
                positive='LOW')
test <- test[order(test$Month,test$Day,test$hour),]
count <- 0
day <- test$Day[1]
for(i in 1:nrow(test))
{
  if(test$Day == day )
  {
  if(test$predicted.response[i]!= test$base_hr_class[i])
  {count <- count+1}
  if(count >= 6)
  {test$Outlier_day[i] <- "TRUE"}else
  {test$Outlier_day[i] <- "FALSE"}
  }else{count <- 0}
  day <- test$Day
}

library(ROCR)
predictions=as.vector(cross.sell.rf.test$votes[,2])
pred=prediction(predictions,as.factor(test$predicted.response))

perf_AUC=performance(pred,"auc") #Calculate the AUC value
AUC=perf_AUC@y.values[[1]]

perf_ROC=performance(pred,"tpr","fpr") #plot the actual ROC curve
plot(perf_ROC, main="ROC plot")
auc <- performance(pred, measure = "auc")
auc <- auc@y.values[[1]]
auc
text(0.5,0.5,paste("AUC = ",format(auc, digits=5, scientific=FALSE)))
name_dataframe <- NULL
building_id$name <- name
write.csv(test,paste0(name,"_prediction_",".csv"))
output_frame <- as.data.frame(output[[2]])
building_desc <- cbind(output_frame, building_id)
confusion_matrix_random <- rbind(confusion_matrix_random,building_desc)
}
write.csv(confusion_matrix_random,"confusion_matrix_all.csv")
